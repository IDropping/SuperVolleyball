namespace TestExam;

public class UnitTest1
{
    [Fact]
    public void Test1()
    {
        //Arrange
        var speed = 9;
        var boost = 8;
        //Act
        var expected = 36;
        var flightTime = 2 * speed / Math.Pow(1,2);
        //Assert
        Assert.Equal(flightTime,expected);
    }
    
    [Fact]
    public void Test2()
    {
        //Arrange
        var speed = 9;
        var boost = 8;
        //Act
        var expected = 18;
        var flightTime = 2 * speed / Math.Pow(1,2);
        //Assert
        Assert.Equal(flightTime,expected);
    }
}