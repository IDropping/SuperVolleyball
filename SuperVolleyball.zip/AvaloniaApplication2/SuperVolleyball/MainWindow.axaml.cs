using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Avalonia.Controls;
using Avalonia.Interactivity;
using AvaloniaApplication2.Classes;
using MsBox.Avalonia;
using MsBox.Avalonia.Enums;
using MySqlConnector;

namespace AvaloniaApplication2;

public partial class MainWindow : Window
{
    public ObservableCollection<SuperVolleyballClass> SuperBall { get; set; }
    public MySqlConnectionStringBuilder ConnectionBuild;
    public int BallId;
    public MainWindow()
    {
        InitializeComponent();
        SuperBall = new ObservableCollection<SuperVolleyballClass>();
        ConnectionBuild = new MySqlConnectionStringBuilder()
        {
            Server = "10.10.0.24",
            Database = "pro1_3",
            UserID = "user01",
            Password = "user01pro"
        };
        ShowTable();
    }

    public void ShowTable()
    {
        using (var connection = new MySqlConnection(ConnectionBuild.ConnectionString))
        {
            connection.Open();
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "SELECT * FROM SuperVolleyball";
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        SuperBall.Add(new SuperVolleyballClass()
                        {
                            Id = reader.GetInt32("Id"),
                            PlayerName = reader.GetString("PlayerName"),
                            Weight = reader.GetInt32("Weight"),
                            Height = reader.GetInt32("Height"),
                            Birthday = reader.GetDateOnly("Birthday"),
                            DateStartGame = reader.GetDateOnly("DateStartGame"),
                            Team = reader.GetString("Team")
                        });
                    }
                }
            }
        }
        SuperVolleyballDaraGrid.ItemsSource = SuperBall;
    }
    private void AddButton_OnClick(object? sender, RoutedEventArgs e)
    {
        try
        {
            using (var connection = new MySqlConnection(ConnectionBuild.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "INSERT INTO (PlayerName, Weight, Height, Birthday, DateStartGame, Team) +" +
                                          "VALUES (@PlayerName, @Weight, @Height, @Birthday, @DateStartGame, Team)";
                    command.Parameters.AddWithValue("@PlayerName", PlayerBox.Text);
                    command.Parameters.AddWithValue("@Weight", Convert.ToInt32(WeightBox.Text));
                    command.Parameters.AddWithValue("@Height", Convert.ToInt32(HeightBox.Text));
                    command.Parameters.AddWithValue("@Birthday", Convert.ToDateTime(BirthdayBox.Text).ToString("yy-MM-dd"));
                    command.Parameters.AddWithValue("@DateStartGame", Convert.ToDateTime(DateGameStartBox.Text).ToString("yy-MM-dd"));
                    command.Parameters.AddWithValue("@Team", TeamBox.Text);

                    command.ExecuteNonQuery();
                }
                connection.Close();
            }
            SuperVolleyballDaraGrid.ItemsSource = SuperBall;
        }
        catch (Exception exception)
        {
            Console.WriteLine("" + exception);
        }
    }

    private void DeleteButton_OnClick(object? sender, RoutedEventArgs e)
    {
        try
        {
            var remove = SuperVolleyballDaraGrid.SelectedItem as SuperVolleyballClass;
            using (var connection = new MySqlConnection(ConnectionBuild.ConnectionString))
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "DELETE FROM SuperVolleyball WHERE ID = @Id";
                connection.Open();
                command.Parameters.AddWithValue("@Id", BallId);
                command.ExecuteNonQuery();
            }
            SuperBall.Remove(remove);
            
            if (SuperBall.Remove(remove))
            {
                MessageBoxManager.GetMessageBoxStandard("Attention", "Successful Delete", ButtonEnum.Ok,
                    MsBox.Avalonia.Enums.Icon.Success);
            }
            else
            {
                MessageBoxManager.GetMessageBoxStandard("Error", "Delete isn't successful", ButtonEnum.Ok, 
                    MsBox.Avalonia.Enums.Icon.Error);
            }
            SuperVolleyballDaraGrid.ItemsSource = SuperBall;
        }
        catch (Exception exception)
        {
            Console.WriteLine("" + exception);
        }
    }

    private void SearchBox_OnTextChanged(object? sender, TextChangedEventArgs e)
    {
        var search = new List<SuperVolleyballClass>(SuperBall);
        search = search.Where(x => x.PlayerName.Contains(SearchBox.Text)).ToList();
        SuperVolleyballDaraGrid.ItemsSource = search;
    }

    private void ComboFilter_OnSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        string selectedItem = (ComboFilter.SelectionBoxItem as ComboBoxItem).Content.ToString();
        if (ComboFilter.SelectionBoxItem == "Reset Filter")
        {
            SuperVolleyballDaraGrid.ItemsSource = SuperBall;
        }
        
        if (ComboFilter.SelectionBoxItem == "Team1")
        {
            var selectedTeam = SuperBall.Where(x => x.PlayerName == selectedItem).ToList();
            SuperVolleyballDaraGrid.ItemsSource = selectedTeam;
        }
    }
}