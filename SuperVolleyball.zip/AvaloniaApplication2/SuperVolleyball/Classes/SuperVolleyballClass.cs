using System;

namespace AvaloniaApplication2.Classes;

public class SuperVolleyballClass
{
    public int Id { get; set; }
    public string PlayerName { get; set; }
    public int Weight { get; set; }
    public int Height { get; set; }
    public DateOnly Birthday { get; set; }
    public DateOnly DateStartGame { get; set; }
    public string Team { get; set; }
}